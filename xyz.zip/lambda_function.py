import boto3
import json
import requests
from requests_aws4auth import AWS4Auth
import logging
import os

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    try:
        # Log the event
        logger.info(f"Event received: {json.dumps(event)}")

        # Get S3 details
        bucket = event['Records'][0]['s3']['bucket']['name']
        key = event['Records'][0]['s3']['object']['key']
        logger.info(f"File uploaded: {key} in bucket {bucket}")

        # Get file from S3
        s3 = boto3.client('s3')
        obj = s3.get_object(Bucket=bucket, Key=key)
        content = obj['Body'].read().decode('utf-8')  # For text files; adjust for PDFs

        # Prepare document for OpenSearch
        document = {
            "filename": key,
            "content": content
        }
        logger.info(f"Document prepared: {document}")

        # OpenSearch setup
        region = 'us-east-1'
        service = 'es'
        credentials = boto3.Session().get_credentials()
        awsauth = AWS4Auth(credentials.access_key,
                          credentials.secret_key,
                          region,
                          service,
                          session_token=credentials.token)
        endpoint = "https://search-dms-search-bkcf5w2daecekngkrx4ydyvy2u.us-east-1.es.amazonaws.com"
        url = f"{endpoint}/docs/_doc"
        headers = {"Content-Type": "application/json"}

        # Index in OpenSearch
        response = requests.post(url, auth=awsauth, headers=headers, data=json.dumps(document))
        logger.info(f"Indexed successfully: {response.text}")

        return {
            "statusCode": 200,
            "body": "File processed and indexed"
        }
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return {
            "statusCode": 500,
            "body": str(e)
        }